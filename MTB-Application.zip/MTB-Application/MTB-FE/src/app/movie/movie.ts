export class Movie {
  public movieId: number;
  public movieName: string;
  public movieHours: string;
  public movieGenre: string;
  public movieLanguage: string;
  public movieDescription: string;
  public movieRating: number;
  public movieDate: Date;
}
